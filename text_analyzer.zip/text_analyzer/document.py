#!/usr/bin/env python

# Define Document class
class Document:
    def __init__(self, text):
        self.text = text



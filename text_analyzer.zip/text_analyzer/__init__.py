from .counter_utils import plot_counter, sum_counters
from .document import Document
